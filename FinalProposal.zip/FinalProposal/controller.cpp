#include <iostream>
#include <vector>
#include <string>
//#include "stdafx.h"
#include "RobotModel.h"
#include "RobotPart.h"
#include "orders.h"
#include "SalesRep.h"
#include "Customer.h"
#include "Head.h"
#include "Arm.h"
#include "Torso.h"
#include "Battery.h"
#include "Locomotor.h"
//#include "..\..\..\std_lib_facilities.h"
#include <iomanip>

using namespace std;

int mainMenu(){
    int c;
    cout << "\nMain Menu\n---------" << endl;
    cout << "1 - Create\n2 - Reports\n3 - Save\n0 - Quit" << endl << "- ";
    cin >> c;
    return c;
}

int menuCreate(){
    int c;
    cout << "\nCreate\n------" << endl;
    cout << "1 - Order\n2 - Customer\n3 - Sales Representative\n4 - Robot Model\n5 - Robot Part\n0 - Quit to Main Menu" << endl << "- ";
    cin >> c;
    return c;
}

int menuReport(){
    int c;
    cout << "\nReport\n------" << endl;
    cout << "1 - Orders\n2 - Customers\n3 - Sales Representatives\n4 - Robot Models\n5 - Robot Parts\n0 - Quit to Main Menu" << endl << "- ";
    cin >> c;
    return c;
}

void controller(){
    // declare
    int menuSelect = 1, choice, choiceCreate, choiceReport,x, i, speed;
	double cost, weight, energy, power;
	string name, tempNum;
	string type[] = { "Head", "Arm", "Torso", "Battery", "Locomotor" };

    // set up vectors
    vector<SalesRep> salesRepLibrary = readSalesRepList();
    vector<Customer> customerLibrary = readCustomerList();
    vector<RobotModel*> modelList = readRobotModels();
    vector<orders> ordersLibrary = readOrderList(modelList);
	vector<RobotPart*> partList = readPartList();
	vector<RobotModel*> temp;
	vector<RobotPart*> temp1;
	vector<RobotPart*> temp2;
	vector<RobotModel*>::iterator cipher;
	vector<RobotPart*>::iterator citer;

    // put in temp sales rep and customer and parts
    /*
    string tempRepName = "Dylan Forsyth", tempRepNum = "12345", tempCust = "Whitie Do Dat", tempCustNum = "21324", tempCustPhone = "(972)345-2354";
    SalesRep tempS(tempRepName, tempRepNum);
    salesRepLibrary.push_back(tempS);
    Customer tempC(tempCust, tempCustNum, tempCustPhone);
    customerLibrary.push_back(tempC);
	partList.push_back(new Head("Test Head", "00000", 1.00, 0));
	partList.push_back(new Arm("Test Arm", "00001", 2.00, 0));
	partList.push_back(new Torso("Test Torso", "00002", 3.00, 0, 0));
	partList.push_back(new Battery("Test Battery", "00003", 4.00, 0, 100, 100));
	partList.push_back(new Locomotor("Test Arm", "00004", 5.00, 0));
    for (citer = partList.begin(); citer != partList.end(); citer++) {
		temp2.push_back(*citer);
	}
	modelList.push_back(new RobotModel("Test model", "10101", temp2));
	temp2.clear();
    */
    // start menu
    while(menuSelect != 0){
        // Get menu select
        if(menuSelect == 1){
            choice = mainMenu();
        }
        // check for choices or exit
        if(choice == 1){
            menuSelect = 0;
            while(menuSelect != 1){
                choiceCreate = menuCreate(); // send to create menu
                if(choiceCreate == 1){
                    // create order
                    cin.ignore();
                    // b and n are just temporary holders for the choices
                    int b, n;
                    string date, orderNum;
                    bool exit = false, got;
                    cout << "\n\nPlease select Sales Representative placing the order:\n";
                    for(size_t i = 0; i < salesRepLibrary.size(); i++){
                        cout << i + 1 << ") ";
                        salesRepLibrary[i].print();
                        cout << endl;
                    }
                    cout << "\n- ";
                    cin >> b;
                    cout << "\nPlease select Customer requesting order:\n";
                    for(size_t i = 0; i < customerLibrary.size(); i++){
                        cout << i + 1 << ") ";
                        customerLibrary[i].print();
                        cout << endl;
                    }
                    cout << "\n- ";
                    cin >> n;
                    cin.ignore();
                    cout << "\nEnter date(MM/DD/YYYY): ";
                    getline(cin, date);

                    // check for repeats in order numbers
                    while(exit == false){
                        got = false;
                        cout << "\nEnter Order Number:";
                        getline(cin, orderNum);
                        for(size_t i = 0; i < ordersLibrary.size(); i++){
                            if(orderNum.compare(ordersLibrary[i].getOrderNum()) == 0)
                                got = true;
                        }
                        if(got == true)
                            cout << "\nThat order number is already being used.\n";
                        else
                            exit = true;
                    }
                    //Finding a model
                    cout << "\nPlease choose a model: " << endl;
                    x = 1;
					for (cipher = modelList.begin(); cipher != modelList.end(); cipher++) {
						cout << x << ") ";
						(*cipher)->printBasic();
                        x++;
					}
					cout << "Choice: ";
					cin >> x;
					cipher = modelList.begin();
					for (i = 0; i != x - 1; i++) {
						cipher++;
					}

                    // put in vector
                    b--; n--;
                    orders temp(salesRepLibrary[b], customerLibrary[n], date, orderNum, (*cipher));
                    ordersLibrary.push_back(temp);

                }else if(choiceCreate == 2){
                    bool exit = false, got;
                    // create customer
                    cin.ignore();
                    string name, number, phone;
                    cout << "\n\nEnter Customer Name: ";
                    getline(cin, name);
                    cout << "\nEnter Customer Phone Number(use (XXX) XXX-XXXX format): ";
                    getline(cin, phone);
                    while(exit == false){
                        got = false;
                        cout << "\nEnter Customer Number: ";
                        getline(cin, number);
                        for(size_t  i = 0; i < customerLibrary.size(); i++){
                            if(number.compare(customerLibrary[i].getCustomerNum()) == 0)
                                got = true;
                        }
                        if(got == true)
                            cout << "\nThat Customer Number is already being use.\n";
                        else
                            exit = true;
                    }
                    // push into customer vector
                    Customer temp(name, number, phone);
                    customerLibrary.push_back(temp);

                }else if(choiceCreate == 3){
                    // create sales rep
                    cin.ignore();
                    // declare
                    string name, number;
                    bool exit = false, got;
                    cout << "\nEnter name of Sales Rep.: ";
                    getline(cin, name);
                    while(exit == false){
                        got = false;
                        cout << "\nEnter Sales Rep. Number: ";
                        getline(cin, number);
                        for(size_t  i = 0; i < salesRepLibrary.size(); i++){
                            if(number.compare(salesRepLibrary[i].getRepNum()) == 0)
                                got = true;
                        }
                        if(got == true)
                            cout << "\nThat Sales Rep. Number is already being used.\n";
                        else
                            salesRepLibrary.push_back(SalesRep(name,number));
                            exit = true;
                    }
                }else if(choiceCreate == 4){
                    //create robot model
					cin.ignore();
					cout << "What is the name of this model: ";
					getline(cin, name);
					cout << "What is the model number: ";
					getline(cin, tempNum);
					for (i = 0; i < 5; i++) {
						int count = -1;
						cout << "Please choose a " << type[i] << endl;
						for (citer = partList.begin(); citer != partList.end(); citer++) {
							if (type[i].compare((*citer)->getType()) == 0) {
								cout << count + 2 << ") ";
								(*citer)->print();
								temp1.push_back(*citer);
								count++;
							}
						}
						cout << "Choice: ";
						cin >> choice;
						temp2.push_back(temp1[choice - 1]);
						temp1.clear();
					}

					modelList.push_back(new RobotModel(name, tempNum, temp2));
                }else if(choiceCreate == 5){
                    //create robot part
					cout << "\nCreating a part \nWhat type of part is it?\n\t1)Head\n\t2)Arm\n\t3)Torso\n\t4)Battery\n\t5)Locomotor\nchoice: ";
					cin >> i;
					i--;
					cin.ignore();
					cout << "What is the name of the part: ";
					getline(cin, name);
					cout << "What is the part number: ";
					getline(cin, tempNum);
					cout << "What is the cost of the part: ";
					cin >> cost;
					cout << "What is the weight of the part: ";
					cin >> weight;
					if (i == 0) {
						partList.push_back(new Head(name, tempNum, cost, weight));
					}
					else if (i == 1) {
						partList.push_back(new Arm(name, tempNum, cost, weight));
					}
					else if (i == 2) {
						cout << "How many battery compartments does this part have: ";
						cin >> speed;
						partList.push_back(new Torso(name, tempNum, cost, weight, speed));
					}
					else if (i == 3) {
						cout << "What is the available energy: ";
						cin >> energy;
						cout << "What is the max power: ";
						cin >> power;
						partList.push_back(new Battery(name, tempNum, cost, weight, energy, power));
					}
					else if (i == 4) {
						partList.push_back(new Locomotor(name, tempNum, cost, weight));
					}

                }else if(choiceCreate == 0){
                    // exit to main menu
                    menuSelect = 1;
                }else{
					cout << "\nThat is not a valid option. Please try again.\n";
                }
            }
        } else if(choice == 2){
            menuSelect = 0;
            while(menuSelect != 1){
                choiceReport = menuReport(); // send to report menu
                if(choiceReport == 1){
                    // view order reports
                    for(size_t  i = 0; i < ordersLibrary.size(); i++){
                        ordersLibrary[i].print();
                    }
                }else if(choiceReport == 2){
                    // view customers reports
                    cin.ignore();
                    string custName;

                    if(ordersLibrary.size() == 0){
                        cout << "There are no orders for any customers. Go sell some models first." << endl;
                    }
                    else{
                        cout << "\nEnter Customer Name: ";
                        getline(cin, custName);
                        // find customer if any
                        for(i = 0; i < ordersLibrary.size(); i++){
                            if(custName.compare(customerLibrary[i].getCustomerName()) == 0){
                                cout << "\nFound! Checking for orders..." << endl;
                                for(int j = 0; j < ordersLibrary.size(); j++){
                                    if(custName.compare(ordersLibrary[j].getCustomerName()) == 0){
                                        cout << "\nFound customer order! Printing...." << endl;
                                        ordersLibrary[j].printDetailedCust();
                                        i = ordersLibrary.size();
                                    }
                                }
                            }else{
                                cout << "Customer not found in directory. Please try again." << endl;
                                break;
                            }
                        }
                    }
                }else if(choiceReport == 3){
                    // view sales rep reports
                    cin.ignore();
                    string custName;
                    if(ordersLibrary.size() == 0){
                        cout << "There are no orders for any Sales Rep. Go sell some models first." << endl;
                    }
                    else{
                        cout << "\nEnter Sales Rep Name: ";
                        getline(cin, custName);
                        // find SalesRep if any
                        for(i = 0; i < ordersLibrary.size(); i++){
                            if(custName.compare(salesRepLibrary[i].getRepName()) == 0){
                                cout << "\nFound! Checking for orders..." << endl;
                                for(int j = 0; j < ordersLibrary.size(); j++){

                                    if(custName.compare(ordersLibrary[j].getRepName()) == 0){
                                        cout << "\nFound order! Printing...." << endl;
                                        ordersLibrary[j].printDetailedSal();
                                    }
                                }
                            }else{
                                cout << "Sales Rep not found in directory. Please try again." << endl;
                                break;
                            }
                        }
                    }
                }else if(choiceReport == 4){
                    // view robot models
					cout << "Listing all models: \n";
					for (cipher = modelList.begin(); cipher != modelList.end(); cipher++) {
						(*cipher)->printBasic();

					}
                }else if(choiceReport == 5){
                    // view robot parts
					cout << "Listing all parts: \n";
					for (citer = partList.begin(); citer != partList.end(); citer++) {
						(*citer)->print();

					}
                }else if(choiceReport == 0){
                    // exit to main menu
                    menuSelect = 1;
                }else{
					cout << "\nThat is not a valid option. Please try again.\n";
                }
            }
        }else if(choice == 0){ // Exit program
            cout << "\n\nThank you for using Robbie's Robot Shop!! Please come again!!\n\n";
            menuSelect = 0;
            break;
        }
        // check for menu's 2, 3 choices
        if(choice == 3){ // Save progress to a file

        }

    }
    makeArmFile(partList);
    makeHeadFile(partList);
    makeTorsoFile(partList);
    makeLocomotorFile(partList);
    makeBatteryFile(partList);
    makeCustomerFile(customerLibrary);
    makeOrderFile(ordersLibrary);
    makeRobotModelFile(modelList);
    makeSalesRepFile(salesRepLibrary);
}

int main(){
    cout << "\n\nWelcome to Robbie's Robot Shop!!\n" << "--------------------------------\n\n";
    controller();
}
