#include <iostream>
#include <string>
//#include "..\..\..\std_lib_facilities.h"
//#include "stdafx.h"
#include "orders.h"
#include "Customer.h"
#include "SalesRep.h"
#include <iostream>
#include <iomanip>

using namespace std;

void orders::print(){
    cout << "Customer: " << customer.getCustomerNum() << " | Model: " << (*robot).getName() <<endl;
}
void orders::printDetailedCust(){
    cout << "Order Number: " << orderNum << " for Model: " << (*robot).getName() << " to arrive on " << date << "\nPrice: $" << fixed << setprecision(2) << robotPrice() << endl;
}
void orders::printDetailedSal(){
    cout <<  "Sold for Model: " << (*robot).getName() << "\nPrice: $" << fixed << setprecision(2) << robotPrice() << endl;
}
double orders::robotPrice() {
    (*robot).setPrice();
	return (*robot).getPrice();
}
