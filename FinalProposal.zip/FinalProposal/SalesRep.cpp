#include <iostream>
#include <string>
//#include "..\..\..\std_lib_facilities.h"
//#include "stdafx.h"
#include "SalesRep.h"
#include <iostream>
#include <iomanip>

using namespace std;

void SalesRep::print(){
    cout << "\nRepresentative Name: " << name << "\nRepresentative Number: " << employeeNum;
}
