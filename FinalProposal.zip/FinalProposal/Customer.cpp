#include <iostream>
#include <string>
//#include "..\..\..\std_lib_facilities.h"
//#include "stdafx.h"
#include "Customer.h"
#include <iostream>
#include <iomanip>

using namespace std;

void Customer::print(){
    cout << "\nCustomer Name: " << name << "\nCustomer Number: " << customerNumber << "\nCustomer Phone Number: " << customerPhone;
}
