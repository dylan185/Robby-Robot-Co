#ifndef CUSTOMER_H_INCLUDED
#define CUSTOMER_H_INCLUDED
#include <string>
#include <vector>
//#include "..\..\..\std_lib_facilities.h"

using namespace std;

class Customer{
public:
    Customer(string n, string num, string phone):
        name(n), customerNumber(num), customerPhone(phone) {}

    // getters
    string getCustomerName(){
        return name;
    }
    string getCustomerNum(){
        return customerNumber;
    }
    string getCustomerPhone(){
        return customerPhone;
    }

    void print();



protected:
    string name;
    string customerNumber;
    string customerPhone;
};

void makeCustomerFile(vector<Customer> customerLibrary);
vector<Customer> readCustomerList();


#endif // CUSTOMER_H_INCLUDED
