#ifndef SALESREP_H_INCLUDED
#define SALESREP_H_INCLUDED
#include <string>
//#include "..\..\..\std_lib_facilities.h"
#include <iostream>
#include <iomanip>
#include <vector>

using namespace std;

class SalesRep{
public:
    SalesRep(string n, string num):
        name(n), employeeNum(num) {}

    //getters
    string getRepName(){
        return name;
    }
    string getRepNum(){
        return employeeNum;
    }
    void print();

protected:
    string name;
    string employeeNum;
};

void makeSalesRepFile(vector<SalesRep> salesRepLibrary);
vector<SalesRep> readSalesRepList();

#endif // SALESREP_H_INCLUDED
