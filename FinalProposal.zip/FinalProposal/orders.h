#ifndef ORDERS_H_INCLUDED
#define ORDERS_H_INCLUDED
#include <string>
//#include "..\..\..\std_lib_facilities.h"
#include "SalesRep.h"
#include "Customer.h"
#include <iostream>
#include <iomanip>
#include <vector>
#include "RobotModel.h"

using namespace std;

class orders{
public:
    orders(SalesRep rep, Customer cust, string d, string num, RobotModel* r):
        representitive(rep), customer(cust), date(d), orderNum(num), robot(r) {}

    double calcShip();
    double calcTax();
    double robotPrice();
    double totalPrice();
    void print();
    void printDetailedCust();
    void printDetailedSal();
    // getters
    string getDate(){
        return date;
    }
    string getOrderNum(){
        return orderNum;
    }
    string getRepName(){
        return representitive.getRepName();
    }
    string getRepNum(){
        return representitive.getRepNum();
    }
    string getCustomerName(){
        return customer.getCustomerName();
    }
    string getCustomerNum(){
        return customer.getCustomerNum();
    }
    string getCustomerPhone(){
        return customer.getCustomerPhone();
    }

protected:
    SalesRep representitive;
    Customer customer;
    string date;
    string orderNum;
    RobotModel* robot;
};

void makeOrderFile(vector<orders> ordersLibrary);
vector<orders> readOrderList(vector<RobotModel*> modelList);


#endif // ORDERS_H_INCLUDED


// use 2 string
