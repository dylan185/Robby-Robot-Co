//#include "stdafx.h"
//#include "../../../std_lib_facilities.h"
#include "Head.h"
#include <iostream>
#include <iomanip>

using namespace std;

void Head::print() {
	cout << "\tType: " << type << setw(8) << " | Name: "  << name << setw(8) << " | Part Number: "  << partNum << endl;
};
string Head::getType() {
	return type;
};
string Head::getName() {
	return name;
};
string Head::getPartNum(){
    return partNum;
}
