#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include "RobotPart.h"
#include "Customer.h"
#include "orders.h"
#include "SalesRep.h"
#include "RobotModel.h"
#include "Head.h"
#include "Arm.h"
#include "Torso.h"
#include "Battery.h"
#include "Locomotor.h"

using namespace std;

void makeArmFile(vector<RobotPart*> partList){
    ofstream makeFile("armFile.txt");

    if(makeFile.is_open()){
        makeFile << "Arm Parts:\n";
        for(size_t i = 0;i < partList.size(); i++){
            if(partList[i]->getType() == "Arm"){
                makeFile << partList[i]->getType() << endl;
                makeFile << partList[i]->getName() << endl;
                makeFile << partList[i]->getPartNum() << endl;
                makeFile << partList[i]->getCost() << endl;
                makeFile << partList[i]->getWeight() << endl << endl;
            }
        }
    }
    else cout << "\nArm file not able to be created!\n";
    return;
}

void makeHeadFile(vector<RobotPart*> partList){
    ofstream makeFile("headFile.txt");

    if(makeFile.is_open()){
        makeFile << "Head Parts:\n";
        for(size_t i = 0;i < partList.size(); i++){
            if(partList[i]->getType() == "Head"){
                makeFile << partList[i]->getType() << endl;
                makeFile << partList[i]->getName() << endl;
                makeFile << partList[i]->getPartNum() << endl;
                makeFile << partList[i]->getCost() << endl;
                makeFile << partList[i]->getWeight() << endl << endl;
            }
        }
    }
    else cout << "\nHead file not able to be created!\n";
    return;
}

void makeTorsoFile(vector<RobotPart*> partList){
    ofstream makeFile("torsoFile.txt");

    if(makeFile.is_open()){
        makeFile << "Torso Parts:\n";
        for(size_t i = 0;i < partList.size(); i++){
            if(partList[i]->getType() == "Torso"){
                makeFile << partList[i]->getType() << endl;
                makeFile << partList[i]->getName() << endl;
                makeFile << partList[i]->getPartNum() << endl;
                makeFile << partList[i]->num_compartments() << endl;
                makeFile << partList[i]->getCost() << endl;
                makeFile << partList[i]->getWeight() << endl << endl;
            }
        }
    }
    else cout << "\nTorso file not able to be created!\n";
    return;
}

void makeLocomotorFile(vector<RobotPart*> partList){
    ofstream makeFile("locomotorFile.txt");

    if(makeFile.is_open()){
        makeFile << "Locomotor Parts:\n";
        for(size_t i = 0;i < partList.size(); i++){
            if(partList[i]->getType() == "Locomotor"){
                makeFile << partList[i]->getType() << endl;
                makeFile << partList[i]->getName() << endl;
                makeFile << partList[i]->getPartNum() << endl;
                makeFile << partList[i]->getMaxSpeed() << endl;
                makeFile << partList[i]->getCost() << endl;
                makeFile << partList[i]->getWeight() << endl << endl;
            }
        }
    }
    else cout << "\nLocomotor file not able to be created!\n";
    return;
}

void makeBatteryFile(vector<RobotPart*> partList){
    ofstream makeFile("batteryFile.txt");

    if(makeFile.is_open()){
        makeFile << "Battery Parts:\n";
        for(size_t i = 0;i < partList.size(); i++){
            if(partList[i]->getType() == "Battery"){
                makeFile << partList[i]->getType() << endl;
                makeFile << partList[i]->getName() << endl;
                makeFile << partList[i]->getPartNum() << endl;
                makeFile << partList[i]->getEnergy() << endl;
                makeFile << partList[i]->getMaxPower() << endl;
                makeFile << partList[i]->getCost() << endl;
                makeFile << partList[i]->getWeight() << endl << endl;
            }
        }
    }
    else cout << "\nBattery file not able to be created!\n";
    return;
}

void makeCustomerFile(vector<Customer> customerLibrary){
    ofstream makeFile("customerFile.txt");

    if(makeFile.is_open()){
        makeFile << "Customers:\n";
        for(size_t i = 0;i < customerLibrary.size(); i++){
            makeFile << customerLibrary[i].getCustomerName() << endl;
            makeFile << customerLibrary[i].getCustomerNum() << endl;
            makeFile << customerLibrary[i].getCustomerPhone() << endl << endl;
        }
    }
    else cout << "\nCustomer file not able to be created!\n";
    return;
}

void makeOrderFile(vector<orders> ordersLibrary){
    ofstream makeFile("orderFile.txt");

    if(makeFile.is_open()){
        makeFile << "Orders:\n";
        for(size_t i = 0;i < ordersLibrary.size(); i++){
            makeFile << ordersLibrary[i].getRepName() << endl;
            makeFile << ordersLibrary[i].getRepNum() << endl;
            makeFile << ordersLibrary[i].getCustomerName() << endl;
            makeFile << ordersLibrary[i].getCustomerNum() << endl;
            makeFile << ordersLibrary[i].getCustomerPhone() << endl;
            makeFile << ordersLibrary[i].getDate() << endl;
            makeFile << ordersLibrary[i].getOrderNum() << endl << endl;
        }
    }
    else cout << "\nOrder file not able to be created!\n";
    return;
}

void makeRobotModelFile(vector<RobotModel*> modelList){
    ofstream makeFile("robotModelFile.txt");

    if(makeFile.is_open()){
        makeFile << "Robot Model:\n";
        for(size_t i = 0;i < modelList.size(); i++){
            vector<RobotPart*> partList = modelList[i]->getPartVector();


            makeFile << endl << modelList[i]->getName() << endl;
            makeFile << modelList[i]->getModelNum() << endl;
            //makeFile << modelList[i]->getPrice() << endl;
            for(size_t j = 0; j < partList.size(); j++){
                if(partList[j]->getType() == "Arm"){
                    makeFile << partList[j]->getType() << endl;
                    makeFile << partList[j]->getName() << endl;
                    makeFile << partList[j]->getPartNum() << endl;
                    makeFile << partList[j]->getCost() << endl;
                    makeFile << partList[j]->getWeight() << endl << endl;
                }
                else if(partList[j]->getType() == "Head"){
                    makeFile << partList[j]->getType() << endl;
                    makeFile << partList[j]->getName() << endl;
                    makeFile << partList[j]->getPartNum() << endl;
                    makeFile << partList[j]->getCost() << endl;
                    makeFile << partList[j]->getWeight() << endl << endl;
                }
                else if(partList[j]->getType() == "Torso"){
                    makeFile << partList[j]->getType() << endl;
                    makeFile << partList[j]->getName() << endl;
                    makeFile << partList[j]->getPartNum() << endl;
                    makeFile << partList[j]->num_compartments() << endl;
                    makeFile << partList[j]->getCost() << endl;
                    makeFile << partList[j]->getWeight() << endl << endl;
                }
                else if(partList[j]->getType() == "Locomotor"){
                    makeFile << partList[j]->getType() << endl;
                    makeFile << partList[j]->getName() << endl;
                    makeFile << partList[j]->getPartNum() << endl;
                    makeFile << partList[j]->getMaxSpeed() << endl;
                    makeFile << partList[j]->getCost() << endl;
                    makeFile << partList[j]->getWeight() << endl << endl;
                }
                else if(partList[j]->getType() == "Battery"){
                    makeFile << partList[j]->getType() << endl;
                    makeFile << partList[j]->getName() << endl;
                    makeFile << partList[j]->getPartNum() << endl;
                    makeFile << partList[j]->getEnergy() << endl;
                    makeFile << partList[j]->getMaxPower() << endl;
                    makeFile << partList[j]->getCost() << endl;
                    makeFile << partList[j]->getWeight() << endl << endl;
                }
                else if (partList[j]->getType() != "\n") cout << "\nUnknown part type found in robot model, skipping entry!\n";
            }
        }
    }
    else cout << "\nRobot model file not able to be created!\n";
    return;
}

void makeSalesRepFile(vector<SalesRep> salesRepLibrary){
    ofstream makeFile("salesRepFile.txt");

    if(makeFile.is_open()){
        makeFile << "Sales Reps:\n";
        for(size_t i = 0;i < salesRepLibrary.size(); i++){
            makeFile << salesRepLibrary[i].getRepName() << endl;
            makeFile << salesRepLibrary[i].getRepNum() << endl << endl;
        }
    }
    else cout << "\nSales Rep file not able to be created!\n";
    return;
}



vector<RobotPart*> readPartList(){
    string readType,readName,readPartNum,strngToDbl,strngToInt,readSpace;
    double readCost,readWeight,readEnergy,readMaxPower;
    int readComp,readMaxSpeed;
    ifstream readArmFile("armFile.txt");
    ifstream readHeadFile("headFile.txt");
    ifstream readTorsoFile("torsoFile.txt");
    ifstream readLocomotorFile("locomotorFile.txt");
    ifstream readBatteryFile("batteryFile.txt");
    vector<RobotPart*> partList;

    if(readArmFile.is_open()){
        getline(readArmFile,readType);
        while(getline(readArmFile,readType)){
            if(readType == "Arm"){
                getline(readArmFile,readName);
                getline(readArmFile,readPartNum);

                getline(readArmFile,strngToDbl);
                stringstream cost;
                cost << strngToDbl;
                cost >> readCost;

                getline(readArmFile,strngToDbl);
                stringstream weight;
                weight << strngToDbl;
                weight >> readWeight;

                getline(readArmFile,readSpace);

                partList.push_back(new Arm(readName, readPartNum, readCost, readWeight));
            }
            else{
                cout << "\nNon-Arm part found in 'armFile.txt', not loading into part list\n";
                while(readType != "\n" && getline(readArmFile,readType));
            }
        }
    }
    else cout << "\nPart: Arm history not found!\n";

    if(readHeadFile.is_open()){
        getline(readHeadFile,readType);
        while(getline(readHeadFile,readType)){
            if(readType == "Head"){
                getline(readHeadFile,readName);
                getline(readHeadFile,readPartNum);

                getline(readHeadFile,strngToDbl);
                stringstream cost;
                cost << strngToDbl;
                cost >> readCost;

                getline(readHeadFile,strngToDbl);
                stringstream weight;
                weight << strngToDbl;
                weight >> readWeight;

                getline(readHeadFile,readSpace);

                partList.push_back(new Head(readName, readPartNum, readCost, readWeight));
            }
            else{
                cout << "\nNon-Head part found in 'headFile.txt', not loading into part list\n";
                while(readType != "\n" && getline(readHeadFile,readType));
            }
        }
    }
    else cout << "\nPart: Head history not found!\n";

    if(readTorsoFile.is_open()){
        getline(readTorsoFile,readType);
        while(getline(readTorsoFile,readType)){
            if(readType == "Torso"){
                getline(readTorsoFile,readName);
                getline(readTorsoFile,readPartNum);

                getline(readTorsoFile,strngToInt);
                stringstream compNum;
                compNum << strngToInt;
                compNum >> readComp;

                getline(readTorsoFile,strngToDbl);
                stringstream cost;
                cost << strngToDbl;
                cost >> readCost;

                getline(readTorsoFile,strngToDbl);
                stringstream weight;
                weight << strngToDbl;
                weight >> readWeight;

                getline(readTorsoFile,readSpace);

                partList.push_back(new Torso(readName, readPartNum, readCost, readWeight, readComp));
            }
            else{
                cout << "\nNon-Torso part found in 'torsoFile.txt', not loading into part list\n";
                while(readType != "\n" && getline(readTorsoFile,readType));
            }
        }
    }
    else cout << "\nPart: Torso history not found!\n";

    if(readLocomotorFile.is_open()){
        getline(readLocomotorFile,readType);
        while(getline(readLocomotorFile,readType)){
            if(readType == "Locomotor"){
                getline(readLocomotorFile,readName);
                getline(readLocomotorFile,readPartNum);

                getline(readLocomotorFile,strngToInt);
                stringstream maxSpeed;
                maxSpeed << strngToInt;
                maxSpeed >> readMaxSpeed;

                getline(readLocomotorFile,strngToDbl);
                stringstream cost;
                cost << strngToDbl;
                cost >> readCost;

                getline(readLocomotorFile,strngToDbl);
                stringstream weight;
                weight << strngToDbl;
                weight >> readWeight;

                getline(readLocomotorFile,readSpace);

                partList.push_back(new Locomotor(readName, readPartNum, readCost, readWeight));
            }
            else{
                cout << "\nNon-Locomotor part found in 'locomotorFile.txt', not loading into part list\n";
                while(readType != "\n" && getline(readLocomotorFile,readType));
            }
        }
    }
    else cout << "\nPart: Locomotor history not found!\n";

    if(readBatteryFile.is_open()){
        getline(readBatteryFile,readType);
        while(getline(readBatteryFile,readType)){
            if(readType == "Battery"){
                getline(readBatteryFile,readName);
                getline(readBatteryFile,readPartNum);

                getline(readBatteryFile,strngToDbl);
                stringstream energy;
                energy << strngToDbl;
                energy >> readEnergy;

                getline(readBatteryFile,strngToDbl);
                stringstream maxPower;
                maxPower << strngToDbl;
                maxPower >> readMaxPower;

                getline(readBatteryFile,strngToDbl);
                stringstream cost;
                cost << strngToDbl;
                cost >> readCost;

                getline(readBatteryFile,strngToDbl);
                stringstream weight;
                weight << strngToDbl;
                weight >> readWeight;

                getline(readBatteryFile,readSpace);

                partList.push_back(new Battery(readName, readPartNum, readCost, readWeight, readEnergy, readMaxPower));
            }
            else{
                cout << "\nNon-Battery part found in 'batteryFile.txt', not loading into part list\n";
                while(readType != "\n" && getline(readBatteryFile,readType));
            }
        }
    }
    //else cout << "\nPart: Battery history not found!\n";

    return partList;
}

vector<Customer> readCustomerList(){
    ifstream readCustomerFile("customerFile.txt");
    vector<Customer> customerList;
    string readSpace, readName, readNum, readPhone;

    if(readCustomerFile.is_open()){
        getline(readCustomerFile,readSpace);
        while(getline(readCustomerFile,readName)){
            getline(readCustomerFile,readNum);
            getline(readCustomerFile,readPhone);
            getline(readCustomerFile,readSpace);
            customerList.push_back(Customer(readName,readNum,readPhone));
        }
    }
    //else cout << "\nCustomer history is not able to be accessed!\n";

    return customerList;
}

vector<orders> readOrderList(vector<RobotModel*> modelList){
    ifstream readOrderFile("orderFile.txt");
    vector<orders> orderList;
    string readSpace,repName,repNum,customerName,customerNum,customerPhone,date,orderNum;
    vector<RobotModel*>::iterator r;
    r = modelList.begin();

    if(readOrderFile.is_open()){
        getline(readOrderFile,readSpace);
        while(repName != "" && getline(readOrderFile,repName)){
            getline(readOrderFile,repNum);
            getline(readOrderFile,customerName);
            getline(readOrderFile,customerNum);
            getline(readOrderFile,customerPhone);
            getline(readOrderFile,date);
            getline(readOrderFile,orderNum);

            getline(readOrderFile,readSpace);

            orderList.push_back(orders(SalesRep(repName,repNum),Customer(customerName,customerNum,customerPhone),date,orderNum,(*r)));
            r++;
        }
    }
    //else cout << "\nOrder history is not able to be accessed!\n";

    return orderList;
}

vector<RobotModel*> readRobotModels(){
    ifstream readRobotModelFile("robotModelFile.txt");
    vector<RobotModel*> robotModelList;
    string readSpace,partType,partName,partNum,modelName,modelNum,modelPrice;
    string strngToDbl,strngToInt;
    double partCost,partWeight,partEnergy,partMaxPower;
    int partCompart,partMaxSpeed,push;

    if(readRobotModelFile.is_open()){
        getline(readRobotModelFile,readSpace);
        getline(readRobotModelFile,readSpace);
        while(getline(readRobotModelFile,modelName)){
            push = 1;
            getline(readRobotModelFile,modelNum);
            //getline(readRobotModelFile,modelPrice);
            vector<RobotPart*> robotPartList;
            while(push && getline(readRobotModelFile,partType)){
                if(partType == "Arm"){
                    getline(readRobotModelFile,partName);
                    getline(readRobotModelFile,partNum);

                    getline(readRobotModelFile,strngToDbl);
                    stringstream cost;
                    cost << strngToDbl;
                    cost >> partCost;

                    getline(readRobotModelFile,strngToDbl);
                    stringstream weight;
                    weight << strngToDbl;
                    weight >> partWeight;

                    robotPartList.push_back(new Arm(partName,partNum,partCost,partWeight));

                    getline(readRobotModelFile,readSpace);

                }
                else if(partType == "Head"){
                    getline(readRobotModelFile,partName);
                    getline(readRobotModelFile,partNum);

                    getline(readRobotModelFile,strngToDbl);
                    stringstream cost;
                    cost << strngToDbl;
                    cost >> partCost;

                    getline(readRobotModelFile,strngToDbl);
                    stringstream weight;
                    weight << strngToDbl;
                    weight >> partWeight;

                    robotPartList.push_back(new Head(partName,partNum,partCost,partWeight));

                    getline(readRobotModelFile,readSpace);
                }
                else if(partType == "Torso"){
                    getline(readRobotModelFile,partName);
                    getline(readRobotModelFile,partNum);

                    getline(readRobotModelFile,strngToInt);
                    stringstream compartments;
                    compartments << strngToInt;
                    compartments >> partCompart;

                    getline(readRobotModelFile,strngToDbl);
                    stringstream cost;
                    cost << strngToDbl;
                    cost >> partCost;

                    getline(readRobotModelFile,strngToDbl);
                    stringstream weight;
                    weight << strngToDbl;
                    weight >> partWeight;

                    robotPartList.push_back(new Torso(partName,partNum,partCost,partWeight,partCompart));

                    getline(readRobotModelFile,readSpace);

                }
                else if(partType == "Locomotor"){
                    getline(readRobotModelFile,partName);
                    getline(readRobotModelFile,partNum);

                    getline(readRobotModelFile,strngToInt);
                    stringstream maxSpeed;
                    maxSpeed << strngToInt;
                    maxSpeed >> partMaxSpeed;

                    getline(readRobotModelFile,strngToDbl);
                    stringstream cost;
                    cost << strngToDbl;
                    cost >> partCost;

                    getline(readRobotModelFile,strngToDbl);
                    stringstream weight;
                    weight << strngToDbl;
                    weight >> partWeight;

                    robotPartList.push_back(new Locomotor(partName,partNum,partCost,partWeight));

                    getline(readRobotModelFile,readSpace);

                }
                else if(partType == "Battery"){
                    getline(readRobotModelFile,partName);
                    getline(readRobotModelFile,partNum);

                    getline(readRobotModelFile,strngToDbl);
                    stringstream cost;
                    cost << strngToDbl;
                    cost >> partCost;

                    getline(readRobotModelFile,strngToDbl);
                    stringstream weight;
                    weight << strngToDbl;
                    weight >> partWeight;

                    getline(readRobotModelFile,strngToDbl);
                    stringstream energy;
                    energy << strngToDbl;
                    energy >> partEnergy;

                    getline(readRobotModelFile,strngToDbl);
                    stringstream maxPower;
                    maxPower << strngToDbl;
                    maxPower >> partMaxPower;

                    robotPartList.push_back(new Battery(partName,partNum,partCost,partWeight,partEnergy,partMaxPower));

                    getline(readRobotModelFile,readSpace);
                }
                else push = 0;

            }
            robotModelList.push_back(new RobotModel(modelName,modelNum,robotPartList));
        }
    }
    //else cout << "\nRobot Model history is not able to be accessed!\n";

    return robotModelList;
}

vector<SalesRep> readSalesRepList(){
    ifstream readSalesRepFile("salesRepFile.txt");
    vector<SalesRep> salesRepList;
    string readSpace, readName, readNum;

    if(readSalesRepFile.is_open()){
        getline(readSalesRepFile,readSpace);
        while(getline(readSalesRepFile,readName)){
            getline(readSalesRepFile,readNum);
            getline(readSalesRepFile,readSpace);
            salesRepList.push_back(SalesRep(readName,readNum));
        }
    }
    //else cout << "\nSales Representative history is not able to be accessed!\n";

    return salesRepList;
}
